/***************************************************************************************
 * Filename: mapproc.c
 *
 * Description: General procedures for the MAP simulator.
 ***************************************************************************************/

#include <map.h>

/***************************************************************************************
 * Name: map_perform_simulation()
 *
 * Purpose: Perform the simulation.
 *
 * Parameters: IN    end_file - file for putting-out end locations
 *             IN    root_data - pointer to a CB containing all the root data for MAP.
 *
 * Returns: Nothing.
 *
 * Operation: Loop through the list of individuals, calling into the function that moves
 *            an individual and stores its position, resource and territorial cue data.  
 *            Repeat this process until root_data->total_time has passed.
 ***************************************************************************************/
void map_perform_simulation(FILE *end_file, MAP_ROOT_DATA *root_data)
{
	/* Local variables */
	MAP_INDIVIDUAL *curr_indiv_cb;
    MAP_POPULATION *curr_pop_cb;
    unsigned long counter;

    /* Sanity checks. Current time step should be 0. */
	assert(root_data != NULL);
	assert(root_data->current_time == 0);
	
	/* Loop through all the individuals, moving them according to the rules and 
     * updating the per-population mark information.
     * Repeat for each time step */
	while(root_data->current_time < root_data->total_time)
	{
        root_data->current_time++;
        curr_pop_cb = (MAP_POPULATION *)LIST_GET_FIRST(root_data->population_list_root);                        
        while(curr_pop_cb != NULL)
        {
            /* Go through individuals in current population, moving each */
			curr_indiv_cb = (MAP_INDIVIDUAL *)LIST_GET_FIRST(curr_pop_cb->individual_list_root);                        
            while(curr_indiv_cb != NULL)
            {
                /* Move the current individual */
                map_move_individual(curr_indiv_cb, curr_pop_cb, root_data);

                if((double)root_data->current_time >= root_data->start_measure_time)
                {
                	/* Print out locations of individuals */
                	printf("%i\t%i\t",curr_indiv_cb->current_x_pos,curr_indiv_cb->current_y_pos);
                	if(((double)root_data->current_time == root_data->total_time) && (end_file != NULL))
                	{
                		/* Last time step.  Print out end locations */
                		fprintf(end_file, "%i\t%i\t",curr_indiv_cb->current_x_pos,curr_indiv_cb->current_y_pos);
					}
			    }
			    
			    /* Individual cannot have moved outside the box */
                assert(curr_indiv_cb->current_x_pos >= 0);
                assert(curr_indiv_cb->current_y_pos >= 0);
                assert(curr_indiv_cb->current_x_pos < root_data->box_width);
                assert(curr_indiv_cb->current_y_pos < root_data->box_height);

                /* Get the next CB */
                curr_indiv_cb = (MAP_INDIVIDUAL *)LIST_GET_NEXT(curr_indiv_cb->list_elt);
            }

			/* Decay marks */
			map_decay_marks(curr_pop_cb, root_data);
			
            /* Get next population */
            curr_pop_cb = (MAP_POPULATION *)LIST_GET_NEXT(curr_pop_cb->list_elt);
        }
        if((double)root_data->current_time >= root_data->start_measure_time)
        {
          	/* Gone through all populations: carriage return */
          	printf("\n");
           	if(((double)root_data->current_time == root_data->total_time) && (end_file != NULL))
           	{
           		/* Last time step.  Print out end locations */
           		fprintf(end_file, "\n");
			}
		}
    }
  
    /* Return */
    return;
}

/***************************************************************************************
 * Name: map_move_individual()
 *
 * Purpose: Move the individual.
 *
 * Parameters: IN/OUT individual - the individual
 *             IN     population - pointer to the population CB containing this individual
 *             IN     root_data - pointer to a CB containing all the root data for MAP.
 *
 * Returns: Nothing.
 *
 * Operation: Move individual and deposit marks
 ***************************************************************************************/
void map_move_individual(MAP_INDIVIDUAL *individual, 
                         MAP_POPULATION *population, 
						 MAP_ROOT_DATA *root_data)
{
	/* Local variables */
	double random;
	double up;
	double down;
	double left;
	double right;
	MAP_POPULATION *curr_pop_cb;

    /* Sanity checks. */
	assert(root_data != NULL);
	assert(individual != NULL);
	assert(population != NULL);
	
    /* Calculate probabilities of moving up/down/left/right */
#ifdef MAP_PBC
	down = 1;
	up = 1;
	left = 1;
	right = 1;
#else /* MAP_PBC */
    if(individual->current_y_pos == 0)
    {
    	/* Cannot move down */
    	down = 0;
	}
	else
	{
    	/* Can move down */
		down = 1;
	}
    if(individual->current_y_pos == root_data->box_height - 1)
    {
    	/* Cannot move up */
    	up = 0;
	}
	else
	{
    	/* Can move up */
		up = 1;
	}
    if(individual->current_x_pos == 0)
    {
    	/* Cannot move left */
    	left = 0;
	}
	else
	{
    	/* Can move left */
		left = 1;
	}
    if(individual->current_x_pos == root_data->box_width - 1)
    {
    	/* Cannot move right */
    	right = 0;
	}
	else
	{
    	/* Can move right */
		right = 1;
	}
#endif /* MAP_PBC */

    /* Go through populations updating probabilities due to mark presence */
    curr_pop_cb = (MAP_POPULATION *)LIST_GET_FIRST(root_data->population_list_root);                        
    while(curr_pop_cb != NULL)
    {
        if(population->resp_to_ave == MAP_NO)
        {
#ifdef MAP_PBC
           	down *= exp(root_data->aijs[curr_pop_cb->index + population->index*root_data->no_pops]*
	    	            curr_pop_cb->marks[individual->current_x_pos + MAP_MOD(individual->current_y_pos - 1,root_data->box_height)*root_data->box_width]+
		    			root_data->env_weight*root_data->env_data[individual->current_x_pos + MAP_MOD(individual->current_y_pos - 1,root_data->box_height)*root_data->box_width]);
       	    up *= exp(root_data->aijs[curr_pop_cb->index + population->index*root_data->no_pops]*
    		          curr_pop_cb->marks[individual->current_x_pos + MAP_MOD(individual->current_y_pos + 1,root_data->box_height)*root_data->box_width]+
    				  root_data->env_weight*root_data->env_data[individual->current_x_pos + MAP_MOD(individual->current_y_pos + 1,root_data->box_height)*root_data->box_width]);
           	left *= exp(root_data->aijs[curr_pop_cb->index + population->index*root_data->no_pops]*
    		            curr_pop_cb->marks[MAP_MOD(individual->current_x_pos - 1,root_data->box_height) + individual->current_y_pos*root_data->box_width]+
    				    root_data->env_weight*root_data->env_data[MAP_MOD(individual->current_x_pos - 1,root_data->box_height) + individual->current_y_pos*root_data->box_width]);
           	right *= exp(root_data->aijs[curr_pop_cb->index + population->index*root_data->no_pops]*
    		             curr_pop_cb->marks[MAP_MOD(individual->current_x_pos + 1,root_data->box_height) + individual->current_y_pos*root_data->box_width]+
    				     root_data->env_weight*root_data->env_data[MAP_MOD(individual->current_x_pos + 1,root_data->box_height) + individual->current_y_pos*root_data->box_width]);
#else /* MAP_PBC */
            if(individual->current_y_pos != 0)
            {
            	down *= exp(root_data->aijs[curr_pop_cb->index + population->index*root_data->no_pops]*
    			            curr_pop_cb->marks[individual->current_x_pos + (individual->current_y_pos - 1)*root_data->box_width]+
    						root_data->env_weight*root_data->env_data[individual->current_x_pos + (individual->current_y_pos - 1)*root_data->box_width]);
        	}
            if(individual->current_y_pos != root_data->box_height - 1)
            {
            	up *= exp(root_data->aijs[curr_pop_cb->index + population->index*root_data->no_pops]*
    			          curr_pop_cb->marks[individual->current_x_pos + (individual->current_y_pos + 1)*root_data->box_width]+
    				      root_data->env_weight*root_data->env_data[individual->current_x_pos + (individual->current_y_pos + 1)*root_data->box_width]);
    	    }
            if(individual->current_x_pos != 0)
            {
            	left *= exp(root_data->aijs[curr_pop_cb->index + population->index*root_data->no_pops]*
    			            curr_pop_cb->marks[individual->current_x_pos - 1 + individual->current_y_pos*root_data->box_width]+
    				        root_data->env_weight*root_data->env_data[individual->current_x_pos - 1 + individual->current_y_pos*root_data->box_width]);
        	}
            if(individual->current_x_pos != root_data->box_width - 1)
            {
            	right *= exp(root_data->aijs[curr_pop_cb->index + population->index*root_data->no_pops]*
    			             curr_pop_cb->marks[individual->current_x_pos + 1 + individual->current_y_pos*root_data->box_width]+
    				         root_data->env_weight*root_data->env_data[individual->current_x_pos + 1 + individual->current_y_pos*root_data->box_width]);
    	    }
#endif /* MAP_PBC */
		}
        else
        {
#ifdef MAP_PBC
           	down *= exp(root_data->aijs[curr_pop_cb->index + population->index*root_data->no_pops]*
	    	            curr_pop_cb->ave_marks[individual->current_x_pos + MAP_MOD(individual->current_y_pos - 1,root_data->box_height)*root_data->box_width]+
		    			root_data->env_weight*root_data->env_data[individual->current_x_pos + MAP_MOD(individual->current_y_pos - 1,root_data->box_height)*root_data->box_width]);
       	    up *= exp(root_data->aijs[curr_pop_cb->index + population->index*root_data->no_pops]*
    		          curr_pop_cb->ave_marks[individual->current_x_pos + MAP_MOD(individual->current_y_pos + 1,root_data->box_height)*root_data->box_width]+
    				  root_data->env_weight*root_data->env_data[individual->current_x_pos + MAP_MOD(individual->current_y_pos + 1,root_data->box_height)*root_data->box_width]);
           	left *= exp(root_data->aijs[curr_pop_cb->index + population->index*root_data->no_pops]*
    		            curr_pop_cb->ave_marks[MAP_MOD(individual->current_x_pos - 1,root_data->box_height) + individual->current_y_pos*root_data->box_width]+
    				    root_data->env_weight*root_data->env_data[MAP_MOD(individual->current_x_pos - 1,root_data->box_height) + individual->current_y_pos*root_data->box_width]);
           	right *= exp(root_data->aijs[curr_pop_cb->index + population->index*root_data->no_pops]*
    		             curr_pop_cb->ave_marks[MAP_MOD(individual->current_x_pos + 1,root_data->box_height) + individual->current_y_pos*root_data->box_width]+
    				     root_data->env_weight*root_data->env_data[MAP_MOD(individual->current_x_pos + 1,root_data->box_height) + individual->current_y_pos*root_data->box_width]);
#else /* MAP_PBC */
            if(individual->current_y_pos != 0)
            {
            	down *= exp(root_data->aijs[curr_pop_cb->index + population->index*root_data->no_pops]*
    			            curr_pop_cb->ave_marks[individual->current_x_pos + (individual->current_y_pos - 1)*root_data->box_width]+
    						root_data->env_weight*root_data->env_data[individual->current_x_pos + (individual->current_y_pos - 1)*root_data->box_width]);
        	}
            if(individual->current_y_pos != root_data->box_height - 1)
            {
            	up *= exp(root_data->aijs[curr_pop_cb->index + population->index*root_data->no_pops]*
    			          curr_pop_cb->ave_marks[individual->current_x_pos + (individual->current_y_pos + 1)*root_data->box_width]+
    				      root_data->env_weight*root_data->env_data[individual->current_x_pos + (individual->current_y_pos + 1)*root_data->box_width]);
    	    }
            if(individual->current_x_pos != 0)
            {
            	left *= exp(root_data->aijs[curr_pop_cb->index + population->index*root_data->no_pops]*
    			            curr_pop_cb->ave_marks[individual->current_x_pos - 1 + individual->current_y_pos*root_data->box_width]+
    				        root_data->env_weight*root_data->env_data[individual->current_x_pos - 1 + individual->current_y_pos*root_data->box_width]);
        	}
            if(individual->current_x_pos != root_data->box_width - 1)
            {
            	right *= exp(root_data->aijs[curr_pop_cb->index + population->index*root_data->no_pops]*
    			             curr_pop_cb->ave_marks[individual->current_x_pos + 1 + individual->current_y_pos*root_data->box_width]+
    				         root_data->env_weight*root_data->env_data[individual->current_x_pos + 1 + individual->current_y_pos*root_data->box_width]);
    	    }
#endif /* MAP_PBC */
		}
        curr_pop_cb = (MAP_POPULATION *)LIST_GET_NEXT(curr_pop_cb->list_elt);
    }
    
    /* Get a random number between 0 and up+down+left+right */
    random = ((double)rand())*(down+up+left+right)/((double)RAND_MAX);

   	/* Use this random number to determine next position */
   	if(random < down)
   	{
   		/* Move down */
#ifdef MAP_PBC
   		individual->current_y_pos = MAP_MOD(individual->current_y_pos - 1, root_data->box_height);
#else /* MAP_PBC */
   		individual->current_y_pos -= 1;
#endif /* MAP_PBC */
	}
	else if(random < down + up)
	{
   		/* Move up */
#ifdef MAP_PBC
   		individual->current_y_pos = MAP_MOD(individual->current_y_pos + 1, root_data->box_height);
#else /* MAP_PBC */
   		individual->current_y_pos += 1;
#endif /* MAP_PBC */
	}
	else if(random < down + up + left)
	{
   		/* Move left */
#ifdef MAP_PBC
   		individual->current_x_pos = MAP_MOD(individual->current_x_pos - 1, root_data->box_width);
#else /* MAP_PBC */
   		individual->current_x_pos -= 1;
#endif /* MAP_PBC */
	}
#ifdef MAP_PBC
   	else
   	{
   		/* Move right */
   		individual->current_x_pos = MAP_MOD(individual->current_x_pos + 1, root_data->box_width);
    }
#else /* MAP_PBC */
   	else if(individual->current_x_pos != root_data->box_width - 1)
   	{
   		/* Move right */
   		individual->current_x_pos += 1;
    }
#endif /* MAP_PBC */
    
    /* Deposit marks */
    if(root_data->max_mark == 0)
    {
        population->marks[individual->current_x_pos + individual->current_y_pos*root_data->box_width] += root_data->rho;
	}
	else
	{
        population->marks[individual->current_x_pos + individual->current_y_pos*root_data->box_width] += 
	      root_data->rho*(root_data->max_mark - population->marks[individual->current_x_pos + individual->current_y_pos*root_data->box_width]);
	}
    
    /* Return */
    return;
}

/***************************************************************************************
 * Name: map_decay_marks()
 *
 * Purpose: Decay scent for a population and find average
 *
 * Parameters: IN/OUT population - the population
 *             IN     root_data - pointer to a CB containing all the root data for MAP.
 *
 * Returns: Nothing.
 ***************************************************************************************/
void map_decay_marks(MAP_POPULATION *population, MAP_ROOT_DATA *root_data)
{
	/* Local variables */
	unsigned long x_val;
	unsigned long y_val;
#ifdef MAP_PBC
    long x_ave;
	long y_ave;
#else /* MAP_PBC */
	unsigned long x_ave;
	unsigned long y_ave;
#endif /* MAP_PBC */
	long ymin;
	long ymax;
	long xmin;
	long xmax;
	double ave_count;

    /* Sanity checks. */
	assert(root_data != NULL);
	assert(population != NULL);
	assert(root_data->mu < 1);
	assert(root_data->mu > 0);

	/* Decay scent */
  	for(y_val = 0; y_val < root_data->box_height; y_val++)
   	{
        for(x_val = 0; x_val < root_data->box_width; x_val++)
        {
    		population->marks[x_val + y_val*root_data->box_width] *= (1-root_data->mu);
		}
	}
	
    /* Average marks */
  	for(y_val = 0; y_val < root_data->box_height; y_val++)
   	{
        for(x_val = 0; x_val < root_data->box_width; x_val++)
        {
        	ave_count = 0;
        	population->ave_marks[x_val + y_val*root_data->box_width] = 0;
#ifdef MAP_PBC
        	ymin = (long)floor((double)y_val - root_data->delta);
        	ymax = (long)ceil((double)y_val + root_data->delta);
        	xmin = (long)floor((double)x_val - root_data->delta);
        	xmax = (long)ceil((double)x_val + root_data->delta);
        	for(y_ave = ymin; y_ave <= ymax; y_ave++)
        	{
            	for(x_ave = xmin; x_ave <= xmax; x_ave++)
            	{
            		if(pow(((double)y_val-(double)y_ave),2)+pow(((double)x_val-(double)x_ave),2) <= pow(root_data->delta,2))
            		{
            			population->ave_marks[x_val + y_val*root_data->box_width] += 
						  population->marks[MAP_MOD(x_ave,root_data->box_width) + MAP_MOD(y_ave,root_data->box_height)*root_data->box_width];
            			ave_count++;
					}
		    	}
			}
			if(ave_count > 0)
			{
    			population->ave_marks[x_val + y_val*root_data->box_width] /= ave_count;
			}
		}
	}
#else /* MAP_PBC */
        	ymin = MAP_MAX(0,(long)floor((double)y_val - root_data->delta));
        	ymax = MAP_MIN(root_data->box_height-1,(long)ceil((double)y_val + root_data->delta));
        	xmin = MAP_MAX(0,(long)floor((double)x_val - root_data->delta));
        	xmax = MAP_MIN(root_data->box_width-1,(long)ceil((double)x_val + root_data->delta));
        	for(y_ave = ymin; y_ave <= ymax; y_ave++)
        	{
            	for(x_ave = xmin; x_ave <= xmax; x_ave++)
            	{
            		if(pow(((double)y_val-(double)y_ave),2)+pow(((double)x_val-(double)x_ave),2) <= pow(root_data->delta,2))
            		{
            			population->ave_marks[x_val + y_val*root_data->box_width] += population->marks[x_ave + y_ave*root_data->box_width];
            			ave_count++;
					}
		    	}
			}
			if(ave_count > 0)
			{
    			population->ave_marks[x_val + y_val*root_data->box_width] /= ave_count;
			}
		}
	}
#endif /* MAP_PBC */

    /* Return */
    return;
}
