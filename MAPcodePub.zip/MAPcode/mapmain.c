/***************************************************************************************
 * Filename: mapmain.c
 *
 * Description: Contains main entry-point into MAP simulator.
 ***************************************************************************************/

#include <map.h>

/***************************************************************************************
 * Name: main()
 *
 * Purpose: Main function into MAP
 *
 * Parameters: (see usage statement below)
 *
 * Returns: zero
 ***************************************************************************************/
int main(int argc, char** argv)
{
	/* Local variables. */	
	double total_time;
    unsigned short no_indivs;
    unsigned short no_pops;
    unsigned long box_width;
    unsigned long box_height;
    MAP_ROOT_DATA *root_data;
	MAP_INDIVIDUAL *curr_indiv_cb;
	MAP_POPULATION *curr_pop_cb;
    unsigned long curr_arg;
    double mu;
    double rho;
    FILE *aij_file;
    FILE *start_file;
    FILE *end_file;
    double start_measure_time;
    unsigned int rseed;
    double delta;
    double max_mark;
    time_t current_time;
    char *c_time_string;
    FILE *env_file;
    double env_weight;
    FILE *mark_resp_file;
 
    /* If no arguments then print usage statement */
	if(argc == 1)
	{
		printf("Usage: map.exe [-i <number-of-individuals> (default = 4)]\n");
		printf("               [-p <number-of-populations> (default = 2)]]\n");
		printf("               [-tt <total-time> (default = 100000)]\n");
		printf("               [-smt <start-measure-time> (default = 0)]\n");
		printf("               [-af <aij-file>]\n");
		printf("               [-bw <box-width> (default = 100)]\n");
		printf("               [-bh <box-height> (default = 100)]\n");
		printf("               [-mu <mu> (default = 0)]\n");
		printf("               [-rho <rho> (default = 0)]\n");
		printf("               [-d <delta> (default = 0)]\n");
		printf("               [-mm <max-mark> (default = 0)]\n");
		printf("               [-r <random seed> (default = 0)]\n");
		printf("               [-ew <environment-weighting> (default = 0)]\n");
		printf("               [-sf <start-file> (default = NULL)]\n");
		printf("               [-ef <end-file> (default = NULL)]\n");
		printf("               [-edf <environmental-data-file> (default = NULL)]\n");
		printf("               [-mrf <mark-response-file> (default = NULL)]\n");
		goto EXIT_LABEL;
	}
	
	/* Default values */
	no_indivs = 4;
	no_pops = 2;
	total_time = 100000;
    aij_file = NULL;
    start_measure_time = 0;
    box_width = 50;
    box_height = 50;
    mu = 0;
    rho = 1;
	rseed = 0;
	max_mark = 0;
	env_weight = 0;
	start_file = NULL;
	end_file = NULL;
	env_file = NULL;
    mark_resp_file = NULL;
	
	/* Process arguments */
    for(curr_arg = 1; curr_arg < argc; curr_arg++)
    {
        if(!strcmp(argv[curr_arg], "-i"))
        {
            /* No of individuals per population */                      
         	no_indivs = atoi(argv[++curr_arg]);
        }
        else if(!strcmp(argv[curr_arg], "-p"))
        {
            /* No of populations */                      
         	no_pops = atoi(argv[++curr_arg]);
        }
        else if(!strcmp(argv[curr_arg], "-tt"))
        {
            /* Total time */
        	total_time = atof(argv[++curr_arg]);
        }
        else if(!strcmp(argv[curr_arg], "-smt"))
        {
            /* Time to start measuring */ 
         	start_measure_time = atof(argv[++curr_arg]);
        }
        else if(!strcmp(argv[curr_arg], "-af"))
        {
            /* File containing a_ij values: detail the extent to which animals of 
			 * population i move towards or away from marks of population j */
        	aij_file = fopen(argv[++curr_arg],"r");
        }
        else if(!strcmp(argv[curr_arg], "-sf"))
        {
            /* File containing start locations.  Contains one row of the form: 
			 *   x_00 y_00 x_01 y_01 ... x_0N y_0N x_10 y_10 x_11 y_11 ... x_1N y_1N ... ... x_n0 y_n0 x_n1 y_n1 ... x_nN y_nN
             * where n is the number of populations and N the number of individuals per population */
        	start_file = fopen(argv[++curr_arg],"r");
        }
        else if(!strcmp(argv[curr_arg], "-ef"))
        {
            /* File for putting end locations in */
        	end_file = fopen(argv[++curr_arg],"w");
        }
        else if(!strcmp(argv[curr_arg], "-edf"))
        {
            /* File containing environmental data */
        	env_file = fopen(argv[++curr_arg],"r");
        }
        else if(!strcmp(argv[curr_arg], "-mrf"))
        {
            /* File containing details of whether individuals from each population should respond to averaged (1) or
			 * non-averaged (0) marks.  Should be a single vertical list. If not present, assume averaged for
			 * each population */
        	mark_resp_file = fopen(argv[++curr_arg],"r");
        }
        else if(!strcmp(argv[curr_arg], "-bw"))
        {
            /* Box width */ 
         	box_width = atol(argv[++curr_arg]);
        }
        else if(!strcmp(argv[curr_arg], "-bh"))
        {
            /* Box height */ 
         	box_height = atol(argv[++curr_arg]);
        }
        else if(!strcmp(argv[curr_arg], "-mu"))
        {
            /* mu parameter: decay of marks */ 
         	mu = atof(argv[++curr_arg]);
        }
        else if(!strcmp(argv[curr_arg], "-rho"))
        {
            /* rho parameter: growth of marks */ 
         	rho = atof(argv[++curr_arg]);
        }
        else if(!strcmp(argv[curr_arg], "-d"))
        {
            /* delta parameter: spatial averaging radius */ 
         	delta = atof(argv[++curr_arg]);
        }
        else if(!strcmp(argv[curr_arg], "-mm"))
        {
            /* Maximum level of marks */ 
         	max_mark = atof(argv[++curr_arg]);
        }
        else if(!strcmp(argv[curr_arg], "-ew"))
        {
            /* Weighting given to the environmental layer */ 
         	env_weight = atof(argv[++curr_arg]);
        }
        else if(!strcmp(argv[curr_arg], "-r"))
        {
            /* Random seed */ 
         	rseed = atoi(argv[++curr_arg]);
        }
        else
        {
            /* Unrecognised parameter */
            fprintf(stderr,"Error: unrecognised parameter: %s\n", argv[curr_arg]);
            goto EXIT_LABEL;
        }
	}
                       
	/* Check a_ij file exists.  Else exit. */
	if(aij_file == NULL)
	{
        fprintf(stderr, "Error: no file for storing a_ij values\n");
        goto EXIT_LABEL;
    }
	
	/* Initialise random seed. */
	if(rseed == 0)
	{
     	srand(time(NULL));
	}
	else
	{
        srand(rseed);
	}

	/* Initialisation: Enter values into CBs and allocate memory where necessary */
    root_data = map_init(no_indivs,
                         no_pops,
                         total_time,
                         start_measure_time,
                         aij_file,
                         box_width,
                         box_height,
                         mu,
						 rho,
						 delta,
						 max_mark,
						 env_file,
						 mark_resp_file,
						 env_weight);
		
	if(root_data == NULL)
	{
		printf("Memory allocation failure\n");
		goto EXIT_LABEL;
	}

	/* Close the various files */
	if(aij_file != NULL)
	{
		fclose(aij_file);
	}

    map_set_init_conds(start_file, root_data);
    current_time = time(NULL);
    c_time_string = ctime(&current_time);
    fprintf(stderr,"Initial conditions set up on %s", c_time_string);                 
    map_perform_simulation(end_file, root_data);
    current_time = time(NULL);
    c_time_string = ctime(&current_time);
    fprintf(stderr,"Simulation finished on %s", c_time_string);                 
	
	/* Free memory allocated */
	map_term(root_data);

EXIT_LABEL:
	TRACE_END
	return(0);
}
