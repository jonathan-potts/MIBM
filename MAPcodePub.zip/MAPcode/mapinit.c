/***************************************************************************************
 * Filename: mapinit.c
 *
 * Description: Initialisation and termination procedures for the MAP simulator.
 ***************************************************************************************/

#include <map.h>

/***************************************************************************************
 * Name: map_init()
 *
 * Purpose: Allocate memory for CBs required for MAP simulator.  Set up initial CB
 *          constants.
 *
 * Parameters: IN     no_indivs - number of individuals per population.
 *             IN     no_pops - number of populations in simulation.
 *             IN     total_time - total time for the simulation.
 *             IN     start_measure_time - time to start measuring output values
 *             IN     aij_file - file containing a_ij values
 *             IN     box_width - width of box
 *             IN     box_height - height of box
 *             IN     mu - mu parameter (decay rate of marks)
 *             IN     rho - rho parameter (marking rate)
 *             IN     delta - delta parameter (local averaging radius)
 *             IN     max_mark - max amount of marks in one place
 *             IN     env_file - file containing data on the environment
 *             IN     mark_resp_file - file containing data on how animals respond to marks
 *             IN     env_weight - weighting given to the environmental layer
 *
 * Returns: root_data - pointer to a CB containing all the root data for MAP.  If
 *                      any memory allocation fail then return NULL.
 *
 * Operation: Allocate memory for root_data.  Input initial values.  For each of
 *            no_indivs individuals, call into the initialisation function for that
 *            individual.
 ***************************************************************************************/
MAP_ROOT_DATA *map_init(unsigned short no_indivs,
                        unsigned short no_pops,
                        double total_time,
                        double start_measure_time,
                        FILE *aij_file,
                        unsigned long box_width,
                        unsigned long box_height,
                        double mu,
                        double rho,
						double delta,
						double max_mark,
						FILE *env_file,
						FILE *mark_resp_file,
						double env_weight)
{
    /* Local variables */
    unsigned short curr_pop;
    MAP_POPULATION *curr_pop_cb;
    MAP_ROOT_DATA *root_data;
    unsigned short rc;
    unsigned long counter;

	/* Sanity checks. */
	assert(aij_file != NULL);
	
    /* Allocate memory for root data */
    root_data = (MAP_ROOT_DATA *)malloc(sizeof(MAP_ROOT_DATA));
	if(root_data == NULL)
	{
		fprintf(stderr,"MEMORY ALLOCATION FAILURE FOR ROOT_DATA\n");
		goto EXIT_LABEL;
	}

    /* Allocate memory for the a_ijs */
	root_data->aijs = (double *)calloc(no_pops*no_pops, sizeof(double));
	if(root_data->aijs == NULL)
	{
		fprintf(stderr,"MEMORY ALLOCATION FAILURE FOR ROOT_DATA->aijs\n");
		free(root_data);
		root_data = NULL;
		goto EXIT_LABEL;
    }

    /* Allocate memory for the environmental data */
	root_data->env_data = (double *)calloc(box_height*box_width,sizeof(double));
	if(root_data->env_data == NULL)
	{
		fprintf(stderr,"MEMORY ALLOCATION FAILURE FOR ROOT_DATA->env_data\n");
		free(root_data);
		root_data = NULL;
		goto EXIT_LABEL;
    }

    /* Initial conditions of all the variables stored on root */
    root_data->total_time = total_time;
    root_data->no_indivs = no_indivs;
    root_data->no_pops = no_pops;
    LIST_CREATE(root_data->population_list_root);
    root_data->start_measure_time = start_measure_time;
    root_data->current_time = 0;
    root_data->box_width = box_width;
    root_data->box_height = box_height;
    root_data->mu = mu;
    root_data->rho = rho;
    root_data->delta = delta;
    root_data->max_mark = max_mark;
    root_data->env_weight = env_weight;

    /* Set up aij-values */
    map_setup_aij(aij_file, root_data);

    /* Put environmental data from file into CB */
    map_setup_env(env_file, root_data);

    /* Initialise populations */
    for(curr_pop = 0; curr_pop < no_pops; curr_pop++)
    {
    	curr_pop_cb = map_pop_init(curr_pop, root_data);
    	if(curr_pop_cb == NULL)
    	{
            fprintf(stderr,"Failed to initialise population %u\n", curr_pop);
            map_term(root_data);
            root_data = NULL;
            goto EXIT_LABEL;
        }
    }
    
    /* Put data about response to marks from file into CBs.  Must happen after populations are initialised. */
    map_setup_mr(mark_resp_file, root_data);

EXIT_LABEL:
    /* Return pointer to the root data */
    return(root_data);
}

/***************************************************************************************
 * Name: map_pop_init()
 *
 * Purpose: Allocate memory for a population.  Set up initial CB values.
 *
 * Parameters: IN     index - index for the population
 *             IN     root_data - pointer to the per-MAP-simulator data.
 *
 * Returns: population - pointer to a CB containing all the per-population data.
 *
 * Operation: Allocate memory for population.  Add the population to the population-list
 *            rooted in root_data.  Input initial values.
 ***************************************************************************************/
MAP_POPULATION *map_pop_init(unsigned short index, MAP_ROOT_DATA *root_data)
{
    /* Local variables */
    MAP_POPULATION *population;
    unsigned short curr_indiv;
    MAP_INDIVIDUAL *curr_indiv_cb;

	/* Sanity checks.  The index must be between 0 and the number of individuals in the
	 * simulation.	 */
	assert(root_data != NULL);
	assert(index < root_data->no_pops);

	/* Allocate memory for the population CB */
	population = (MAP_POPULATION *)malloc(sizeof(MAP_POPULATION));
	if(population == NULL)
	{
		fprintf(stderr, "MEMORY ALLOCATION FAILURE FOR POPULATION\n");
		goto EXIT_LABEL;
	}

	/* Add population to list in root_data */
    LIST_ADD_TO_START(root_data->population_list_root,
         	          population->list_elt,
    	              population);

	/* Input initial values */
    population->index = index;

    /* Allocate memory for the mark array */
    population->marks = (double *)calloc(root_data->box_width*root_data->box_height, sizeof(double));
	if(population->marks == NULL)
	{
		fprintf(stderr,"MEMORY ALLOCATION FAILURE FOR POPULATION->marks\n");
		free(population);
		goto EXIT_LABEL;
	}

    /* Allocate memory for the averaged mark array */
    population->ave_marks = (double *)calloc(root_data->box_width*root_data->box_height, sizeof(double));
	if(population->ave_marks == NULL)
	{
		fprintf(stderr,"MEMORY ALLOCATION FAILURE FOR POPULATION->ave_marks\n");
		free(population->marks);
		free(population);
		goto EXIT_LABEL;
	}

    /* Create the individual list */
    LIST_CREATE(population->individual_list_root);

    /* Initialise individuals */
    for(curr_indiv = 0; curr_indiv < root_data->no_indivs; curr_indiv++)
    {
    	curr_indiv_cb = map_indiv_init(curr_indiv, population, root_data);
    	if(curr_indiv_cb == NULL)
    	{
            fprintf(stderr,"Failed to initialise individual %u\n", curr_indiv);
            map_term(root_data);
            root_data = NULL;
            goto EXIT_LABEL;
        }
    }

EXIT_LABEL:
	/* Return pointer to the population */
	return(population);
}

/***************************************************************************************
 * Name: map_indiv_init()
 *
 * Purpose: Allocate memory for an individual.  Set up initial CB values.
 *
 * Parameters: IN     index - index for the individual
 *             IN     population - pointer to the population containing this individual
 *             IN     root_data - pointer to the per-MAP-simulator data.
 *
 * Returns: individual - pointer to a CB containing all the per-individual data.
 *
 * Operation: Allocate memory for individual.  Add the individual to the individual-list
 *            rooted in root_data.  Input initial values.
 ***************************************************************************************/
MAP_INDIVIDUAL *map_indiv_init(unsigned short index, MAP_POPULATION *population, MAP_ROOT_DATA *root_data)
{
    /* Local variables */
    MAP_INDIVIDUAL *individual;

	/* Sanity checks.  The index must be between 0 and the number of individuals in the
	 * simulation.	 */
	assert(root_data != NULL);
	assert(index < root_data->no_indivs);

	/* Allocate memory for the individual CB */
	individual = (MAP_INDIVIDUAL *)malloc(sizeof(MAP_INDIVIDUAL));
	if(individual == NULL)
	{
		fprintf(stderr, "MEMORY ALLOCATION FAILURE FOR INDIVIDUAL\n");
		goto EXIT_LABEL;
	}

	/* Add individual to list in populaiton CB */
    LIST_ADD_TO_START(population->individual_list_root,
         	          individual->list_elt,
    	              individual);

	/* Input initial values.  Put all positions to outside the box.  Correct positions will be allocated later */
    individual->index = index;
    individual->current_x_pos = root_data->box_width;
    individual->current_y_pos = root_data->box_height;

EXIT_LABEL:
	/* Return pointer to the individual */
	return(individual);
}

/***************************************************************************************
 * Name: map_setup_aij()
 *
 * Purpose: Get the a_ij-values from file and store in root_data->aijs.
 *
 * Parameters: IN     aij_file - pointer to file containing a_ij-values as a matrix
 *             IN     root_data - pointer to a CB containing all the root data for MAP.
 *
 * Returns: rc - return code.  Either MAP_RC_OK if ok or MAP_RC_ERROR if error.
 *
 * Operation: Read in a_ij values from a file that lists a_ij-values as follows:
 *               a_11 a_12 ... a_1N
 *                  ...
 *                  ...
 *               a_N1 a_N2 ... a_NN
 *            where N=root_data->no_indivs and there is a tab (\t) between each value. 
 *            Here, a_ij is the response of individuals from population i to marks of j.
 ***************************************************************************************/
unsigned short map_setup_aij(FILE *aij_file, MAP_ROOT_DATA *root_data)
{
	/* Local variables */
	double curr_val = 0;
	char curr_char;
	char prev_char;
	unsigned long y_val = 0;
	unsigned long x_val = 0;
	double digit_after_dec = 0;
	unsigned short neg = MAP_NO;
	unsigned short rc = MAP_RC_OK;
    
	/* Sanity checks */
	assert(aij_file != NULL);
	assert(root_data != NULL);
	assert(root_data->aijs != NULL);

    /* Get numbers from file */
    rewind(aij_file);
	curr_char = getc(aij_file);
	while(curr_char != EOF)
	{
		if((curr_char >= '0') && (curr_char <= '9') && (digit_after_dec == 0))
        { 
            /* This is a digit of a number */
            curr_val = curr_val*10+(double)(curr_char-'0');
        }
  		else if((curr_char >= '0') && (curr_char <= '9'))
        { 
            /* This is a digit of a number after the decimal point */
            curr_val += (double)(curr_char-'0')/pow(10,digit_after_dec);
            digit_after_dec++;
        }
        else if(curr_char == '-')
        {
            /* Negative number */
            neg = MAP_YES;
        }
        else if(curr_char == '.')
        {
            /* Decimal point. */
            digit_after_dec++;
        }
		else if((curr_char == '\n') && (prev_char >= '0') && (prev_char <= '9'))
		{
            /* End of row of numbers */
            assert(x_val < root_data->no_pops);
            assert(y_val < root_data->no_pops);
            if(neg == MAP_NO)
            {
                root_data->aijs[x_val+y_val*root_data->no_pops] = curr_val;
			}
			else
			{
                root_data->aijs[x_val+y_val*root_data->no_pops] = -curr_val;
			}
            curr_val = 0;
            y_val++;
            x_val = 0;
            digit_after_dec = 0;
            neg = MAP_NO;
        } 
		else if((curr_char == '\n') && (prev_char == '\t'))
		{
            /* End of row of numbers after a tab.  No need to store values in array.  Just
             * change x_val and y_val to reflect the fact that we are about to start a new
             * row.  */
            assert(x_val <= root_data->no_pops); /* could have x_val=no_pops due to tab */
            assert(y_val < root_data->no_pops);
            curr_val = 0;
            y_val++;
            x_val = 0;
            digit_after_dec = 0;
            neg = MAP_NO;
        } 
    	else if((curr_char == '\t') && (prev_char >= '0') && (prev_char <= '9'))
		{
            /* End of a number */
            assert(x_val < root_data->no_pops);
            assert(y_val < root_data->no_pops);
            if(neg == MAP_NO)
            {
                root_data->aijs[x_val+y_val*root_data->no_pops] = curr_val;
			}
			else
			{
                root_data->aijs[x_val+y_val*root_data->no_pops] = -curr_val;
			}
            curr_val = 0;
            x_val++;
            digit_after_dec = 0;
            neg = MAP_NO;
        }                            
        else
        {
            /* Unrecognised character.  Maybe benign.  No-op */
        }             
        prev_char = curr_char;              
    	curr_char = getc(aij_file);
	}
	if((prev_char >= '0') && (prev_char <= '9'))
	{
		/* Got to the end of the file but not stored final value */
        assert(x_val < root_data->no_pops);
        assert(y_val < root_data->no_pops);
        if(neg == MAP_NO)
        {
            root_data->aijs[x_val+y_val*root_data->no_pops] = curr_val;
        }
		else
		{
            root_data->aijs[x_val+y_val*root_data->no_pops] = -curr_val;
		}
	}
	        
EXIT_LABEL:   
	/* Return */
	return(rc);
}

/***************************************************************************************
 * Name: map_set_init_conds()
 *
 * Purpose: Set up initial conditions for all variables
 *
 * Parameters: IN     start_file - file contining initial conditions
 *             IN     root_data - pointer to a CB containing all the root data for MAP.
 *
 * Returns: Nothing.
 *
 * Operation: Set up position data in individual CB from the start data in ROOT.
 *            Set the current_time_step in ROOT to 0.
 ***************************************************************************************/
 void map_set_init_conds(FILE *start_file, MAP_ROOT_DATA *root_data)
 {
	/* Local variables */
	MAP_INDIVIDUAL *curr_indiv_cb;
    MAP_POPULATION *curr_pop_cb;
	unsigned long x_val;
	unsigned long y_val;
 	unsigned long counter;
	unsigned long curr_val = 0;
	char curr_char;
	char prev_char;
	unsigned short xy_val;

	/* Sanity checks */
	assert(root_data != NULL);

    if(start_file == NULL)
    {
        /* Update positions on population and individual CBs based on random sampling. */
        curr_pop_cb = (MAP_POPULATION *)LIST_GET_FIRST(root_data->population_list_root);                        
        while(curr_pop_cb != NULL)
        {
        	assert(curr_pop_cb->marks != NULL);
            for(x_val = 0; x_val < root_data->box_width; x_val++)
            {
                for(y_val = 0; y_val < root_data->box_height; y_val++)
                {
                    curr_pop_cb->marks[x_val+y_val*root_data->box_width] = 0;
                    curr_pop_cb->ave_marks[x_val+y_val*root_data->box_width] = 0;
                }
            }
            curr_indiv_cb = (MAP_INDIVIDUAL *)LIST_GET_FIRST(curr_pop_cb->individual_list_root);                        
            while(curr_indiv_cb != NULL)
            {
       	        curr_indiv_cb->current_x_pos = rand() % root_data->box_width;
                curr_indiv_cb->current_y_pos = rand() % root_data->box_height;

                /* Get next individual */
                curr_indiv_cb = (MAP_INDIVIDUAL *)LIST_GET_NEXT(curr_indiv_cb->list_elt);
            }
            /* Get next population */
            curr_pop_cb = (MAP_POPULATION *)LIST_GET_NEXT(curr_pop_cb->list_elt);
        }
	}
	else
	{
        /* Update positions on population and individual CBs based on file. */
    	rewind(start_file);
		curr_char = getc(start_file);
        curr_pop_cb = (MAP_POPULATION *)LIST_GET_FIRST(root_data->population_list_root);                        
        curr_indiv_cb = (MAP_INDIVIDUAL *)LIST_GET_FIRST(curr_pop_cb->individual_list_root);    
		xy_val = MAP_X;                    
		while(curr_char != EOF)
		{
			if((curr_char >= '0') && (curr_char <= '9'))
	        { 
	            /* This is a digit of a number */
	            curr_val = curr_val*10+(unsigned long)(curr_char-'0');
	        }
			else if(((curr_char == '\n') || (curr_char == '\t')) && (prev_char >= '0') && (prev_char <= '9'))
			{
	            /* End of number */
	            if(xy_val == MAP_X)
	            {
	            	/* Got an x-value */
					assert(curr_indiv_cb != NULL);
    	            curr_indiv_cb->current_x_pos = curr_val;
    	            curr_val = 0;
    	            xy_val = MAP_Y;
				}
				else
				{
					/* Got a y-value */
					assert(curr_indiv_cb != NULL);
					assert(xy_val == MAP_Y);
    	            curr_indiv_cb->current_y_pos = curr_val;					
    	            curr_val = 0;
    	            xy_val = MAP_X;
    	            
                    /* Get next individual */
                    curr_indiv_cb = (MAP_INDIVIDUAL *)LIST_GET_NEXT(curr_indiv_cb->list_elt);
    	            
    	            /* If next individual is NULL, get the next population */
    	            if(curr_indiv_cb == NULL)
    	            {
                        /* Get next population */
       					assert(curr_pop_cb != NULL);
                        curr_pop_cb = (MAP_POPULATION *)LIST_GET_NEXT(curr_pop_cb->list_elt);
                        if(curr_pop_cb != NULL)
                        {
                        	/* Get the first individual from this list */
                            curr_indiv_cb = (MAP_INDIVIDUAL *)LIST_GET_FIRST(curr_pop_cb->individual_list_root);                        
						}
						else
						{
							/* Run out of populations.  Break. */
							break;
						}
					}
				}
	        } 
	        prev_char = curr_char;              
	    	curr_char = getc(start_file);
		}
		if((prev_char >= '0') && (prev_char <= '9'))
		{
			/* Got to the end of the file but not stored final value */
            if((xy_val == MAP_X) && (curr_indiv_cb != NULL))
            {
            	/* Got an x-value */
   	            curr_indiv_cb->current_x_pos = curr_val;
   	            xy_val = MAP_Y;
			}
			else if(curr_indiv_cb != NULL) 
			{
				/* Got a y-value */
				assert(xy_val == MAP_Y);
   	            curr_indiv_cb->current_y_pos = curr_val;					
            }
		}
	}
    
    /* Set initial time in root data */
    root_data->current_time = 0;
   
    /* Return */
	return;
}

/***************************************************************************************
 * Name: map_term()
 *
 * Purpose: Free all memory allocated in map_init.
 *
 * Parameters: IN     root_data - pointer to a CB containing all the root data for MAP.
 *
 * Returns: Nothing.
 ***************************************************************************************/
void map_term(MAP_ROOT_DATA *root_data)
{
    /* Local variables */
    MAP_POPULATION *curr_pop_cb;

	/* Sanity checks. */
	assert(root_data != NULL);

    /* Free up populations */		
    if(LIST_EMPTY(root_data->population_list_root))
    {
    	free(root_data);
    	goto EXIT_LABEL;
    }
    curr_pop_cb = (MAP_POPULATION *)LIST_GET_FIRST(root_data->population_list_root);
    while(curr_pop_cb != NULL)
    {
        /* Delete the first element on the list.  Then free the associated control block.
         * Then get the new first element. */
        LIST_DELETE_FIRST(root_data->population_list_root);
    	map_pop_term(curr_pop_cb);
    	curr_pop_cb = (MAP_POPULATION *)LIST_GET_FIRST(root_data->population_list_root);
    }

    /* Free root */
	free(root_data);
        
EXIT_LABEL:
    /* Return */
    return;
}

/***************************************************************************************
 * Name: map_pop_term()
 *
 * Purpose: Free all memory allocated in map_pop_init().
 *
 * Parameters: IN     population - pointer to per-population data.
 *
 * Returns: Nothing.
 *
 * Operation: Free per-population memory.
 ***************************************************************************************/
void map_pop_term(MAP_POPULATION *population)
{
	/* Local variables */
    MAP_INDIVIDUAL *curr_indiv_cb;

	/* Sanity checks */
	assert(population != NULL);

	/* Free up mark array */
	free(population->marks);

    curr_indiv_cb = (MAP_INDIVIDUAL *)LIST_GET_FIRST(population->individual_list_root);
    while(curr_indiv_cb != NULL)
    {
        /* Delete the first element on the list.  Then free the associated control block.
         * Then get the new first element. */
        LIST_DELETE_FIRST(population->individual_list_root);
    	map_indiv_term(curr_indiv_cb);
    	curr_indiv_cb = (MAP_INDIVIDUAL *)LIST_GET_FIRST(population->individual_list_root);
    }

	/* Free up the memory allocated for the individual control block */
	free(population);

	/* Return */
	return;
}

/***************************************************************************************
 * Name: map_indiv_term()
 *
 * Purpose: Free all memory allocated in map_indiv_init().
 *
 * Parameters: IN     individual - pointer to per-individual data.
 *
 * Returns: Nothing.
 *
 * Operation: Free per-individual memory.
 ***************************************************************************************/
void map_indiv_term(MAP_INDIVIDUAL *individual)
{
	/* Local variables */

	/* Sanity checks */
	assert(individual != NULL);

	/* Free up the memory allocated for the individual control block */
	free(individual);

	/* Return */
	return;
}

/***************************************************************************************
 * Name: map_setup_env()
 *
 * Purpose: Put environmental data from file into array
 *
 * Parameters: IN     env_file - file contining environmental data
 *             IN     root_data - pointer to a CB containing all the root data for MAP.
 *
 * Returns: Nothing.
 *
 * Operation: If the file is NULL then put zeros in the environmental data array.  Else
 *            populate the array with numbers from file.
 ***************************************************************************************/
void map_setup_env(FILE *env_file, MAP_ROOT_DATA *root_data)
{
	/* Local variables */
	double curr_val = 0;
	char curr_char;
	char prev_char;
	unsigned long y_val;
	unsigned long x_val;
	double digit_after_dec = 0;
	unsigned short neg = MAP_NO;
	unsigned short rc = MAP_RC_OK;

	/* Sanity checks */
	assert(root_data != NULL);

  	/* Populate environmental data array with default values of zero */
   	for(y_val = 0; y_val < root_data->box_height; y_val++)
	{
       	for(x_val = 0; x_val < root_data->box_width; x_val++)
    	{
		    root_data->env_data[y_val*root_data->box_width+x_val] = 0;
	    }
	}
	x_val = 0;
	y_val = 0;
    if(env_file != NULL)
	{
		/* Populate environmental data array with values from file */
        /* Get numbers from file */
        rewind(env_file);
	    curr_char = getc(env_file);
	    while(curr_char != EOF)
	    {
    		if((curr_char >= '0') && (curr_char <= '9') && (digit_after_dec == 0))
            { 
                /* This is a digit of a number */
                curr_val = curr_val*10+(double)(curr_char-'0');
            }
      		else if((curr_char >= '0') && (curr_char <= '9'))
            { 
                /* This is a digit of a number after the decimal point */
                curr_val += (double)(curr_char-'0')/pow(10,digit_after_dec);
                digit_after_dec++;
            }
            else if(curr_char == '-')
            {
                /* Negative number */
                neg = MAP_YES;
            }
            else if(curr_char == '.')
            {
                /* Decimal point. */
                digit_after_dec++;
            }
    		else if((curr_char == '\n') && (prev_char >= '0') && (prev_char <= '9'))
    		{
                /* End of row of numbers */
                assert(x_val < root_data->box_width);
                assert(y_val < root_data->box_height);
                if(neg == MAP_NO)
                {
                    root_data->env_data[x_val+y_val*root_data->box_width] = curr_val;
    			}
    			else
    			{
                    root_data->env_data[x_val+y_val*root_data->box_width] = -curr_val;
    			}
                curr_val = 0;
                y_val++;
                x_val = 0;
                digit_after_dec = 0;
                neg = MAP_NO;
            } 
    		else if((curr_char == '\n') && (prev_char == '\t'))
    		{
                /* End of row of numbers after a tab.  No need to store values in array.  Just
                 * change x_val and y_val to reflect the fact that we are about to start a new
                 * row.  */
                assert(x_val <= root_data->box_width); /* could have x_val=box_width due to tab */
                assert(y_val < root_data->box_height);
                curr_val = 0;
                y_val++;
                x_val = 0;
                digit_after_dec = 0;
                neg = MAP_NO;
            } 
        	else if((curr_char == '\t') && (prev_char >= '0') && (prev_char <= '9'))
    		{
                /* End of a number */
                assert(x_val < root_data->box_width);
                assert(y_val < root_data->box_height);
                if(neg == MAP_NO)
                {
                    root_data->env_data[x_val+y_val*root_data->box_width] = curr_val;
    			}
    			else
    			{
                    root_data->env_data[x_val+y_val*root_data->box_width] = -curr_val;
    			}
                curr_val = 0;
                x_val++;
                digit_after_dec = 0;
                neg = MAP_NO;
            }                            
            else
            {
                /* Unrecognised character.  Maybe benign.  No-op */
            }             
            prev_char = curr_char;              
        	curr_char = getc(env_file);
    	}
    	if((prev_char >= '0') && (prev_char <= '9'))
    	{
    		/* Got to the end of the file but not stored final value */
            assert(x_val < root_data->box_width);
            assert(y_val < root_data->box_height);
            if(neg == MAP_NO)
            {
                root_data->env_data[x_val+y_val*root_data->box_width] = curr_val;
            }
    		else
    		{
                root_data->env_data[x_val+y_val*root_data->box_width] = -curr_val;
    		}
    	}
	}

	/* Return */
	return;
}

/***************************************************************************************
 * Name: map_setup_mr()
 *
 * Purpose: Put data about mark responses from file into array
 *
 * Parameters: IN     mark_resp_file - file contining data
 *             IN     root_data - pointer to a CB containing all the root data for MAP.
 *
 * Returns: Nothing.
 *
 * Operation: Set up a local array of mark response values.  If the file is NULL then put 
 *            values of MAP_YES into this local array, else read in from file: if file says
 *            0 then store as MAP_NO, else store as MAP_YES.  Then put values into
 *            respective population CBs
 ***************************************************************************************/
void map_setup_mr(FILE *mark_resp_file, MAP_ROOT_DATA *root_data)
{
	/* Local variables */
	unsigned short *resp_to_ave;
	unsigned short pop_id;
	MAP_POPULATION *curr_pop_cb;
	char curr_char;

	/* Sanity checks */
	assert(root_data != NULL);
	
	/* Set up a local array of mark response values */
	resp_to_ave = calloc(root_data->no_pops,sizeof(unsigned short));
	
    /* Put MAP_YES into the local array by default */
    for(pop_id = 0; pop_id < root_data->no_pops; pop_id++)
	{
		resp_to_ave[pop_id] = MAP_YES;
	}
	if(mark_resp_file != NULL)
	{
		/* File is not NULL so read info from file */
        rewind(mark_resp_file);
	    curr_char = getc(mark_resp_file);
	    pop_id = 0;
	    while(curr_char != EOF)
	    {
			if(curr_char == '0')
	        { 
	            /* Got a zero: flag not to use averaged marks */
	            assert(pop_id < root_data->no_pops);
	            resp_to_ave[pop_id] = MAP_NO;
	            pop_id++;
	        }
			else if(curr_char == '1')
	        { 
	            /* Got a one: flag to use averaged marks */
	            assert(pop_id < root_data->no_pops);
	            resp_to_ave[pop_id] = MAP_YES;
	            pop_id++;
	        }
			else if(curr_char != '\n')
	        { 
                fprintf(stderr, "Warning: unexpected character %c in mark response file \n", curr_char);
	        }
        	curr_char = getc(mark_resp_file);
		}
	}
	
    /* Put data from local array to population CBs */
    curr_pop_cb = (MAP_POPULATION *)LIST_GET_FIRST(root_data->population_list_root);                        
    while(curr_pop_cb != NULL)
    {
    	curr_pop_cb->resp_to_ave=resp_to_ave[curr_pop_cb->index];
        curr_pop_cb = (MAP_POPULATION *)LIST_GET_NEXT(curr_pop_cb->list_elt);
    }

    /* Free memory allocated locally */
    free(resp_to_ave);
    
	/* Return */
	return;
}

